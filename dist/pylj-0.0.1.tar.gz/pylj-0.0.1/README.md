# pylj

This is a simple python code to perform simple lennard-jonesium 2D simulation. 

The aim of this is to use in a computational/physical chemistry laboratory excersize. 

Install:

```
python setup.py build
python setup.py install 
```

Requires C++ complier.

Contact:
arm61@bath.ac.uk
